using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Burst;
using Unity.Collections;
using Unity.Jobs;
using Unity.Mathematics;
using System;
using Unity.VisualScripting;

public class WorldGenerator : MonoBehaviour
{
    // Start is called before the first frame updateprivate int ChunkNumber = 11;
    public GameObject ChunkPrefab;
    private GameObject[,] ChunkArr;
    //private ChunkGenerator[,] ChunkGeneratorsArr;

    //Perlin Generation:
    public static int seed = 1200;
    public float heightMultiplier = 5f;
    public int pixelLength;

    //infinite terrain
    public Transform player;
    Dictionary<string, ChunkGenerator> chunkDictionary;
    public List<ChunkGenerator> presentChunkList;

    public int drawDistance;

    public int chunkWidth;
    public int chunkHeight;

    public float mapZoom;
    public int mapZScale;

    List<ChunkJobHandler> chunkJobs;

    int refreshChunkTimer = 60;
    int refreshChunkTimerIndex;

    bool loading;
    float loadingTime = 0;

    public GameObject menu;

    public void Start()
    {
        presentChunkList = new List<ChunkGenerator>();
        chunkDictionary = new Dictionary<string, ChunkGenerator>();
        chunkJobs = new List<ChunkJobHandler>();
        seed *= 1000;

        int playerX = (int) (player.transform.position.x/(chunkWidth*(3f/4f)));
        int playerZ = (int) (player.transform.position.z/(chunkWidth*Mathf.Sqrt(3)/2));

        for (int x = playerX - drawDistance; x < playerX + drawDistance; x++)
        {
            for (int y = playerZ - drawDistance; y < playerZ + drawDistance; y++)
            {
                CreateAndScheduleChunkJob(x, y);
            }
        }
        loading = true;
        ProcessRunningJobs();
    }

    public void Update()
    {
        ProcessRunningJobs();

        if(loading && chunkJobs.Count==0){
            loadingTime += Time.deltaTime;
            if(loadingTime>1f){
                loading = false;
                player.gameObject.SetActive(true);
                menu.SetActive(false);
            }
        }
        if(++refreshChunkTimerIndex > refreshChunkTimer){
            refreshChunkTimerIndex = 0;
            QueueNewChunks();
            DisableFarChunks();
        }
    }

    public void QueueNewChunks(){
        Vector2Int chunkCoordinates = GetChunkCoordinates(player.transform.position.x, player.transform.position.z);
        for(int x = chunkCoordinates.x-drawDistance; x < chunkCoordinates.x+drawDistance; x++){
            for(int z = chunkCoordinates.y-drawDistance; z < chunkCoordinates.y+drawDistance; z++){
                if(ChunkExists(x,z)){
                    ChunkGenerator chunk = GetChunk(x,z);
                    GetChunk(x,z).gameObject.SetActive(true);
                }else{
                    CreateAndScheduleChunkJob(x,z);
                }       
            }
        }
    }

    public void DisableFarChunks(){
        int playerX = (int) (player.transform.position.x/(chunkWidth*(3f/4f)));
        int playerZ = (int) (player.transform.position.z/(chunkWidth*Mathf.Sqrt(3)/2));

        foreach(ChunkGenerator chunk in chunkDictionary.Values){
            if(Mathf.Abs(chunk.worldX - playerX) > drawDistance*1.5 || Mathf.Abs(chunk.worldZ - playerZ) > drawDistance *1.5){
                chunk.gameObject.SetActive(false);
            }

        }


    }



    public void ProcessRunningJobs(){
        foreach(ChunkJobHandler job in chunkJobs){
            if(job.IsCompleted()){
                job.Complete();
                if(ChunkExists(job.x,job.z)){
                    ChunkGenerator chunk = GetChunk(job.x,job.z);
                    chunk.GenerateMesh(job.vertexNativeList.ToArray(Allocator.Temp).ToArray(), job.uvNativeList.ToArray(Allocator.Temp).ToArray(), job.triangleNativeList.ToArray(Allocator.Temp).ToArray(), job.blockTypeMap);
                }else{
                    Debug.LogError("ERROR: Completed Job has no gameobject");
                }

                job.ClearMemory();
                chunkJobs.Remove(job);
                return;            
            }
        }
    }

    public void CreateAndScheduleChunkJob(int x, int z)
    {
        GameObject CurrentChunkObject = Instantiate(ChunkPrefab, transform.position, transform.rotation, transform);
        ChunkGenerator currentChunkScript = CurrentChunkObject.GetComponent<ChunkGenerator>();
        currentChunkScript.worldX = x;
        currentChunkScript.worldZ = z;

        CurrentChunkObject.name = currentChunkScript.getIndexKey();
        presentChunkList.Add(currentChunkScript);
        chunkDictionary.Add(CurrentChunkObject.name, currentChunkScript);

        float xPos = chunkWidth * x * (3f/4f);
        float zPos = chunkWidth * z * Mathf.Sqrt(3)/2 + x%2 * (chunkWidth%2) * Mathf.Sqrt(3)/4;

        currentChunkScript.transform.position = new Vector3(xPos, 0, zPos);

        NativeList<float3> vertices = new NativeList<float3>(12 * chunkWidth * chunkWidth * chunkHeight, Allocator.Persistent);
        NativeList<float2> uvs = new NativeList<float2>(12 * chunkWidth * chunkWidth * chunkHeight, Allocator.Persistent);
        NativeList<int> triangles = new NativeList<int>(60 * chunkWidth * chunkWidth * chunkHeight, Allocator.Persistent);
        NativeHashMap<float3, int> blockTypeMap = new NativeHashMap<float3, int>(chunkWidth * chunkWidth * chunkHeight, Allocator.Persistent);

        NativeHashMap<float3,int> blankMap = new NativeHashMap<float3, int>(0, Allocator.TempJob);
        NativeHashMap<float3, int> localForwardBlockTypeMap = new NativeHashMap<float3, int>(0, Allocator.TempJob);
        NativeHashMap<float3, int> localLeftChunkBlockTypeMap = new NativeHashMap<float3, int>(0, Allocator.TempJob);
        NativeHashMap<float3, int> localRightBlockTypeMap = new NativeHashMap<float3, int>(0, Allocator.TempJob);
        NativeHashMap<float3, int> localBackwardBlockTypeMap = new NativeHashMap<float3, int>(0, Allocator.TempJob);

        //get adjacent chunk data, if it exists:
        bool forwardChunkExists = ChunkExists(x,z+1) && chunkDictionary[getChunkKey(x, z+1)].isGenerated;
        bool leftChunkExists = ChunkExists(x-1,z) && chunkDictionary[getChunkKey(x-1, z)].isGenerated;
        bool rightChunkExists = ChunkExists(x+1,z) && chunkDictionary[getChunkKey(x+1, z)].isGenerated;
        bool backwardChunkExists = ChunkExists(x,z-1)  && chunkDictionary[getChunkKey(x, z-1)].isGenerated;

        if(forwardChunkExists){
            localForwardBlockTypeMap = chunkDictionary[getChunkKey(x, z+1)].blockType;
        }

        if(leftChunkExists){
            localLeftChunkBlockTypeMap = chunkDictionary[getChunkKey(x-1, z)].blockType;
        }

        if(rightChunkExists){
            localRightBlockTypeMap = chunkDictionary[getChunkKey(x+1, z)].blockType;
        }

        if(backwardChunkExists){
            localBackwardBlockTypeMap = chunkDictionary[getChunkKey(x, z-1)].blockType;
        }
        ChunkJob chunkJob = new ChunkJob(){
            width = chunkWidth,
            height = chunkHeight,
            worldX = x,
            worldZ = z,
            scale = mapZoom,
            zScale = mapZScale,

            vertexNativeList = vertices,
            uvNativeList = uvs,
            triangleNativeList = triangles,
            blockTypeMap = blockTypeMap,

            forwardChunkExist = forwardChunkExists,
            leftChunkExist = leftChunkExists,
            rightChunkExist = rightChunkExists,
            backwardChunkExist = backwardChunkExists,

            forwardBlockTypeMap = localForwardBlockTypeMap,
            backBlockTypeMap = localBackwardBlockTypeMap,
            rightBlockTypeMap = localRightBlockTypeMap,
            leftBlockTypeMap = localLeftChunkBlockTypeMap
        };

        chunkJobs.Add(new ChunkJobHandler(chunkJob, false, chunkJob.Schedule(), vertices, uvs, triangles, blockTypeMap, x, z));
    }

    ChunkJobHandler ScheduleRebuildJob(ChunkGenerator chunk){
        int x = chunk.worldX;
        int z = chunk.worldZ;

        NativeList<float3> vertices = new NativeList<float3>(12 * chunkWidth * chunkWidth * chunkHeight, Allocator.Persistent);
        NativeList<float2> uvs = new NativeList<float2>(12 * chunkWidth * chunkWidth * chunkHeight, Allocator.Persistent);
        NativeList<int> triangles = new NativeList<int>(60 * chunkWidth * chunkWidth * chunkHeight, Allocator.Persistent);
        NativeHashMap<float3, int> blockTypeMap = chunk.blockType;

        NativeHashMap<float3,int> blankMap = new NativeHashMap<float3, int>(0, Allocator.TempJob);
        NativeHashMap<float3, int> localForwardBlockTypeMap = new NativeHashMap<float3, int>(0, Allocator.TempJob);
        NativeHashMap<float3, int> localLeftChunkBlockTypeMap = new NativeHashMap<float3, int>(0, Allocator.TempJob);
        NativeHashMap<float3, int> localRightBlockTypeMap = new NativeHashMap<float3, int>(0, Allocator.TempJob);
        NativeHashMap<float3, int> localBackwardBlockTypeMap = new NativeHashMap<float3, int>(0, Allocator.TempJob);

        //get adjacent chunk data, if it exists:
        bool forwardChunkExists = ChunkExists(x,z+1) && chunkDictionary[getChunkKey(x, z+1)].isGenerated;
        bool leftChunkExists = ChunkExists(x-1,z) && chunkDictionary[getChunkKey(x-1, z)].isGenerated;
        bool rightChunkExists = ChunkExists(x+1,z) && chunkDictionary[getChunkKey(x+1, z)].isGenerated;
        bool backwardChunkExists = ChunkExists(x,z-1)  && chunkDictionary[getChunkKey(x, z-1)].isGenerated;

        if(forwardChunkExists){
            localForwardBlockTypeMap = chunkDictionary[getChunkKey(x, z+1)].blockType;
        }

        if(leftChunkExists){
            localLeftChunkBlockTypeMap = chunkDictionary[getChunkKey(x-1, z)].blockType;
        }

        if(rightChunkExists){
            localRightBlockTypeMap = chunkDictionary[getChunkKey(x+1, z)].blockType;
        }

        if(backwardChunkExists){
            localBackwardBlockTypeMap = chunkDictionary[getChunkKey(x, z-1)].blockType;
        }
        RebuildChunkJob chunkJob = new RebuildChunkJob(){
            width = chunkWidth,
            height = chunkHeight,
            worldX = x,
            worldZ = z,
            scale = mapZoom,
            zScale = mapZScale,

            vertexNativeList = vertices,
            uvNativeList = uvs,
            triangleNativeList = triangles,
            blockTypeMap = blockTypeMap,

            forwardChunkExist = forwardChunkExists,
            leftChunkExist = leftChunkExists,
            rightChunkExist = rightChunkExists,
            backwardChunkExist = backwardChunkExists,

            forwardBlockTypeMap = localForwardBlockTypeMap,
            backBlockTypeMap = localBackwardBlockTypeMap,
            rightBlockTypeMap = localRightBlockTypeMap,
            leftBlockTypeMap = localLeftChunkBlockTypeMap
        };

        return new ChunkJobHandler(chunkJob, true, chunkJob.Schedule(), vertices, uvs, triangles, blockTypeMap, x, z);
    }

    public ChunkGenerator GetChunk(int xIndex, int zIndex)
    {
        ChunkGenerator temp = null;
        chunkDictionary.TryGetValue(getChunkKey(xIndex,zIndex), out temp);
        return temp;
    }

    public bool ChunkExists(int xIndex, int zIndex){
        return chunkDictionary.ContainsKey(xIndex + "," + zIndex);
    }

    public String getChunkKey(int x, int z){
        return x + "," + z;
    }

    public Vector2Int GetChunkCoordinates(float x, float z){
        return new Vector2Int((int) (player.transform.position.x/(chunkWidth*(3f/4f))),(int) (player.transform.position.z/(chunkWidth*Mathf.Sqrt(3)/2)));
    }

    void OnApplicationQuit(){
        foreach(ChunkGenerator chunk in chunkDictionary.Values){
            chunk.Dispose();
        }
    }

    public ChunkGenerator[] GetNineAdjacent(int x, int z){
        List<ChunkGenerator> adjacentChunks = new();

        for(int checkX = x -1; checkX <= x + 1; checkX++){
            for(int checkZ = z - 1; checkZ <= z + 1; checkZ++){
                if(ChunkExists(checkX, checkZ)){
                    adjacentChunks.Add(GetChunk(x,z));
                }
            }
        }
        return adjacentChunks.ToArray();
    }
    public void SetBlock(Vector3 rayHitPosition, ChunkGenerator chunkHit, int blockType, bool secondCall){
        float chunkWorldX = chunkHit.worldX * chunkWidth*(3f/4f);
        float chunkWorldZ = chunkHit.worldZ * chunkWidth*Mathf.Sqrt(3)/2;

        float hitXCoord = rayHitPosition.x - chunkWorldX;
        float hitZCoord = rayHitPosition.z - chunkWorldZ;

        int indexX = Mathf.Clamp((int) Mathf.Floor(hitXCoord / (3f/4f)),0,chunkWidth);
        int indexY = (int) Mathf.Floor(rayHitPosition.y /0.5f);
        int indexZ = Mathf.Clamp((int) Mathf.Floor((hitZCoord + indexX%2*(Mathf.Sqrt(3)/4))/ (Mathf.Sqrt(3)/2)),0,chunkWidth);

        int closestX = indexX;
        int closestZ = indexZ;

        Vector2 remainderFloat = new(hitXCoord, hitZCoord);
        float closestDistance = Mathf.Infinity;
        for(int checkX = indexX -2; checkX <= indexX + 2; checkX++){
            for(int checkZ = indexZ -2; checkZ <= indexZ + 2;  checkZ++){
                float checkDistance = Vector2.Distance(remainderFloat,convertIndexToLocalHexPosition(checkX,checkZ));
                if(checkDistance < closestDistance){
                    bool satisfiesAddDeleteCheck = ((!chunkHit.blockType.ContainsKey(new float3(checkX,indexY,checkZ)) || chunkHit.blockType[new float3(checkX,indexY,checkZ)] == 0) && blockType > 0) || (blockType == 0 && chunkHit.blockType.ContainsKey(new float3(checkX,indexY,checkZ)) && chunkHit.blockType[new float3(checkX,indexY,checkZ)] > 0);
                    if(satisfiesAddDeleteCheck){
                        closestX = checkX;
                        closestZ = checkZ;
                        closestDistance = checkDistance;
                    }
                }
            }
        }

        if(closestX < 0 || closestX >= chunkWidth || closestZ < 0 || closestZ > chunkWidth){
            //placing into adjacent block.
            if(blockType>0 && !secondCall){
                Debug.Log("x" + closestX + " z " + closestZ);

                int adjacentX = chunkHit.worldX;
                int adjacentZ = chunkHit.worldZ;

                if(closestX < 0){
                    adjacentX--;
                }else if(closestX >= chunkWidth){
                    adjacentX++;
                }

                if(closestZ < 0){
                    adjacentZ--;
                }else if(closestZ >= chunkWidth){
                    adjacentZ++;
                }

                if(ChunkExists(adjacentX,adjacentZ)){
                    SetBlock(rayHitPosition,GetChunk(adjacentX,adjacentZ),blockType,true);
                }
                return;
            }else{
                closestX = Mathf.Clamp(closestX,0,chunkWidth);
                closestZ = Mathf.Clamp(closestZ,0,chunkWidth);
            }
        }

        chunkHit.blockType[new Vector3(closestX,indexY,closestZ)] = blockType;        
        ChunkJobHandler job = ScheduleRebuildJob(chunkHit);
        job.Complete();
        chunkHit.GenerateMesh(job.vertexNativeList.ToArray(Allocator.Temp).ToArray(), job.uvNativeList.ToArray(Allocator.Temp).ToArray(), job.triangleNativeList.ToArray(Allocator.Temp).ToArray(), job.blockTypeMap);
        job.ClearMemory();

        //if editing a chunk on the border, we need to update the adjacent chunk's visibility
        //todo: check before scheduling job that none is currently running.
        if(closestX == 0 && ChunkExists(chunkHit.worldX-1, chunkHit.worldZ)){
            ChunkJobHandler leftJob = ScheduleRebuildJob(GetChunk(chunkHit.worldX-1, chunkHit.worldZ));
            chunkJobs.Add(leftJob);
        }

        if(closestX == chunkWidth && ChunkExists(chunkHit.worldX+1, chunkHit.worldZ)){
            ChunkJobHandler rightJob = ScheduleRebuildJob(GetChunk(chunkHit.worldX+1, chunkHit.worldZ));
            chunkJobs.Add(rightJob);
        }

        if(closestZ == 0 && ChunkExists(chunkHit.worldX, chunkHit.worldZ-1)){
            ChunkJobHandler botJob = ScheduleRebuildJob(GetChunk(chunkHit.worldX, chunkHit.worldZ-1));
            chunkJobs.Add(botJob);
        }

        if(closestZ == chunkWidth && ChunkExists(chunkHit.worldX, chunkHit.worldZ+1)){
            ChunkJobHandler topJob = ScheduleRebuildJob(GetChunk(chunkHit.worldX, chunkHit.worldZ+1));
            chunkJobs.Add(topJob);
        }
    }

    public Vector2 convertIndexToLocalHexPosition(int x, int z){
        return new Vector2(x*0.75f,z*Mathf.Sqrt(3)/2+x%2*Mathf.Sqrt(3)/4);
    }
}
