using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Burst;
using Unity.Collections;
using Unity.Jobs;
using Unity.Mathematics;

[BurstCompile(CompileSynchronously = true)]
public struct RebuildChunkJob : IJob
{
    // Start is called before the first frame update    
    [ReadOnly] public int width;
    [ReadOnly] public int height;
    [ReadOnly] public float scale;

    [ReadOnly] public int worldX;

    [ReadOnly] public int worldZ;

    [ReadOnly] public int zScale;
    [ReadOnly] public static readonly HexMeshData emptyHex = new HexMeshData(1);

    public NativeList<float3> vertexNativeList;
    public NativeList<float2> uvNativeList;
    public NativeList<int> triangleNativeList;
    
    [ReadOnly] public NativeHashMap<float3, int> blockTypeMap;
    [ReadOnly] public NativeHashMap<float3, int> forwardBlockTypeMap;
    [ReadOnly] public NativeHashMap<float3, int> backBlockTypeMap;
    [ReadOnly] public NativeHashMap<float3, int> rightBlockTypeMap;
    [ReadOnly] public NativeHashMap<float3, int> leftBlockTypeMap;

    public bool forwardChunkExist; 
    public bool leftChunkExist;
    public bool rightChunkExist; 
    public bool backwardChunkExist;

    public void Execute()
    {
        GenerateMeshData();
    }

    float getPerlinValue(int x,int y, int z){
        float3 center = calculateLocalHexCenter(x,y,z);
        float2 offset = new float2(width * worldX * (.3f/.4f),width * worldZ * Mathf.Sqrt(3)/2)*scale;
        float2 worldVector = scale * new float2(center.x,center.z) + offset;

        return Mathf.PerlinNoise(worldVector.x, worldVector.y)* zScale + 1;
    }

    float2 getPositionFromIndex(int index){
        return new float2(index/width, index % width);
    }

    static float3 calculateLocalHexCenter(int x, int y, int z){
        float xMid = x * (.3f/.4f);
        float yMid = y * .5f;
        float zMid = z * Mathf.Sqrt(3)/2 + Mathf.Abs(x%2) * Mathf.Sqrt(3)/4;
        
        return new float3(xMid, yMid, zMid);
    }


    public void GenerateMeshData(){
        int vertexOffset = 0;
        for(int x = 0; x < width; x++){
            for(int y = 0; y < height; y++){
                for(int z = 0; z < width; z++){
                    HexMeshData hexMeshData = getVisibleDataForHex(x,y,z,vertexOffset);
                    vertexNativeList.AddRange(hexMeshData.GetVertices());
                    uvNativeList.AddRange(hexMeshData.getUvs());
                    triangleNativeList.AddRange(hexMeshData.getTriangles());
                    vertexOffset+=hexMeshData.GetVertices().Length;
                }
            }
        }
    }

    HexMeshData getVisibleDataForHex(int x, int y, int z, int vertexOffset){
        
        int blockValue = 0;
        if(blockTypeMap.TryGetValue(new float3(x,y,z), out blockValue)){
            if(blockValue == 0){
                return emptyHex;
            }
        }

        NativeArray<bool> adjacentBlocks = new NativeArray<bool>(8, Allocator.Temp);

        adjacentBlocks[2] = blockPresent(x,y,z-1);
        adjacentBlocks[5] = blockPresent(x,y,z+1);
        adjacentBlocks[6] = blockPresent(x,y+1,z);
        adjacentBlocks[7] = blockPresent(x,y-1,z);

        if(x%2 == 0){
            adjacentBlocks[0] = blockPresent(x+1,y,z);
            adjacentBlocks[1] = blockPresent(x+1,y,z-1);

            adjacentBlocks[3] = blockPresent(x-1,y,z-1);
            adjacentBlocks[4] = blockPresent(x-1,y,z);
        }else{
            adjacentBlocks[0] = blockPresent(x+1,y,z+1);
            adjacentBlocks[1] = blockPresent(x+1,y,z);

            adjacentBlocks[3] = blockPresent(x-1,y,z);
            adjacentBlocks[4] = blockPresent(x-1,y,z+1);
        }
        
        return new HexMeshData(x,y,z,blockValue,vertexOffset,worldX,worldZ,adjacentBlocks);
    }

    public bool blockPresent(int x, int y, int z){
        int blockType = 0;
        if(x < 0){
            if(leftChunkExist){
                leftBlockTypeMap.TryGetValue(new float3(width+x,y,z), out blockType);
            }else{
                return y < getPerlinValue(x,y,z);
            }
        }else if(x >= width){
            if(rightChunkExist){
                rightBlockTypeMap.TryGetValue(new float3(x-width,y,z), out blockType);
            }else{
                return y < getPerlinValue(x,y,z);
            }
        }else if(z < 0){
            if(backwardChunkExist){
                backBlockTypeMap.TryGetValue(new float3(x,y,width+z), out blockType);
            }else{
                return y < getPerlinValue(x,y,z);
            }
        }else if(z >= width){
            if(forwardChunkExist){
                forwardBlockTypeMap.TryGetValue(new float3(x,y,z-width), out blockType);
            }else{
                return y < getPerlinValue(x,y,z);
            }
        }else if(y < 0){
            return true;
        }else if(y >= height){
            return false;
        }else{
            blockTypeMap.TryGetValue(new float3(x,y,z), out blockType);
        }
        return blockType != 0;
    }
    public struct HexMeshData {
        NativeList<float3> vertices;
        NativeList<float2> uvs;
        NativeList<int> triangles;

        public HexMeshData(int empty){
            vertices = new NativeList<float3>(0, Allocator.Persistent);
            uvs = new NativeList<float2>(0, Allocator.Persistent);
            triangles = new NativeList<int>(0, Allocator.Persistent);
        }

        public HexMeshData(int x, int y, int z, int blockType, int vertexOffset, int worldX, int worldZ, NativeArray<bool> neighborsPresent){
            vertices = new NativeList<float3>(12, Allocator.Persistent);
            uvs = new NativeList<float2>(12, Allocator.Persistent);
            triangles = new NativeList<int>(60, Allocator.Persistent);


            float3 middlePoint = calculateLocalHexCenter(x,y,z);
            float xMid = middlePoint.x;
            float yMid = middlePoint.y;
            float zMid = middlePoint.z;

            vertices.Add(new float3(xMid + 0.5f,yMid, zMid));
            vertices.Add(new float3(xMid + 0.25f,yMid, zMid - Mathf.Sqrt(3)/4));
            vertices.Add(new float3(xMid - 0.25f,yMid, zMid - Mathf.Sqrt(3)/4));
            vertices.Add(new float3(xMid - 0.5f,yMid, zMid));
            vertices.Add(new float3(xMid - 0.25f,yMid, zMid + Mathf.Sqrt(3)/4));
            vertices.Add(new float3(xMid + 0.25f,yMid, zMid + Mathf.Sqrt(3)/4));
            vertices.Add(new float3(xMid + 0.5f,yMid+0.5f, zMid));
            vertices.Add(new float3(xMid + 0.25f,yMid+0.5f, zMid - Mathf.Sqrt(3)/4));
            vertices.Add(new float3(xMid - 0.25f,yMid+0.5f, zMid - Mathf.Sqrt(3)/4));
            vertices.Add(new float3(xMid - 0.5f,yMid+0.5f, zMid));
            vertices.Add(new float3(xMid - 0.25f,yMid+0.5f, zMid + Mathf.Sqrt(3)/4));
            vertices.Add(new float3(xMid + 0.25f,yMid+0.5f, zMid + Mathf.Sqrt(3)/4));

            float2 start = new float2(0.05f + (blockType-1)*0.1f,0.91f);
            float2 end = new float2(0.05f + (blockType-1)*0.1f,0.81f);            
            for(int i = 0; i < 6; i ++){
                uvs.Add(end);
            }
            for(int i = 0; i < 6; i ++){
                uvs.Add(start);
            }

            //topR:
            if(!neighborsPresent[0]){
                triangles.Add(vertexOffset);
                triangles.Add(vertexOffset+11);
                triangles.Add(vertexOffset + 5);

                triangles.Add(vertexOffset);
                triangles.Add(vertexOffset + 6);
                triangles.Add(vertexOffset + 11);                    
            }

            //botR:
            if(!neighborsPresent[1]){

                triangles.Add(vertexOffset);
                triangles.Add(vertexOffset+1);
                triangles.Add(vertexOffset + 7);

                triangles.Add(vertexOffset);
                triangles.Add(vertexOffset + 7);
                triangles.Add(vertexOffset + 6);
            }

            //bot:
            if(!neighborsPresent[2]){
                triangles.Add(vertexOffset+7);
                triangles.Add(vertexOffset+1);
                triangles.Add(vertexOffset + 2);

                triangles.Add(vertexOffset + 8);
                triangles.Add(vertexOffset + 7);
                triangles.Add(vertexOffset + 2);   
            }

            //botL:
            if(!neighborsPresent[3]){
                triangles.Add(vertexOffset + 9);
                triangles.Add(vertexOffset + 8);
                triangles.Add(vertexOffset + 2);

                triangles.Add(vertexOffset + 9);
                triangles.Add(vertexOffset + 2);
                triangles.Add(vertexOffset + 3);
            }

            //topL:
            if(!neighborsPresent[4]){
                triangles.Add(vertexOffset + 10);
                triangles.Add(vertexOffset + 9);
                triangles.Add(vertexOffset + 3);

                triangles.Add(vertexOffset + 10);
                triangles.Add(vertexOffset + 3);
                triangles.Add(vertexOffset + 4);
            }

            //top:
            if(!neighborsPresent[5]){
                triangles.Add(vertexOffset + 11);
                triangles.Add(vertexOffset + 10);
                triangles.Add(vertexOffset + 4);

                triangles.Add(vertexOffset + 11);
                triangles.Add(vertexOffset + 4);
                triangles.Add(vertexOffset + 5);
            }

            //topY
            if(!neighborsPresent[6]){
                triangles.Add(vertexOffset + 8);
                triangles.Add(vertexOffset + 6);
                triangles.Add(vertexOffset + 7);

                triangles.Add(vertexOffset + 9);
                triangles.Add(vertexOffset + 6);
                triangles.Add(vertexOffset + 8);

                triangles.Add(vertexOffset + 11);
                triangles.Add(vertexOffset + 6);
                triangles.Add(vertexOffset + 9);

                triangles.Add(vertexOffset + 11);
                triangles.Add(vertexOffset + 9);
                triangles.Add(vertexOffset + 10);
            }
            //botY
            if(!neighborsPresent[7]){

                triangles.Add(vertexOffset);
                triangles.Add(vertexOffset + 2);
                triangles.Add(vertexOffset + 1);

                triangles.Add(vertexOffset);
                triangles.Add(vertexOffset + 3);
                triangles.Add(vertexOffset + 2);

                triangles.Add(vertexOffset);
                triangles.Add(vertexOffset + 5);
                triangles.Add(vertexOffset + 3);

                triangles.Add(vertexOffset + 3);
                triangles.Add(vertexOffset + 5);
                triangles.Add(vertexOffset + 4);
            }
        }
        public NativeList<float3> GetVertices(){
            return vertices;
        }
        public NativeList<float2> getUvs(){
            return uvs;
        }

        public NativeList<int> getTriangles(){
            return triangles;
        }
    }
}
