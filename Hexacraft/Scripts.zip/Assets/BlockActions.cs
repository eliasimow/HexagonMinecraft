using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockActions : MonoBehaviour
{
    public WorldGenerator worldGenerator;
    private LayerMask layerMask = (1 << 0);
    private ChunkGenerator[] adjacentChunks;
    private ChunkGenerator targetedChunk;
    private int maxDistance = 20;

    int playerX;
    int playerZ;
    public Material highlightedMaterial;
    public Material normalMaterial;


    void Start()
    {
        adjacentChunks = worldGenerator.GetNineAdjacent(playerX,playerZ);
    }

    void Update()
    {
        
        int newPlayerX = (int) (transform.position.x/(worldGenerator.chunkWidth*(3f/4f)));
        int newPlayerZ = (int) (transform.position.z/(worldGenerator.chunkWidth*Mathf.Sqrt(3)/2));

        if(playerX != newPlayerX || playerZ != newPlayerZ){
            playerX = newPlayerX;
            playerZ = newPlayerZ;
            adjacentChunks = worldGenerator.GetNineAdjacent(playerX,playerZ);
        }


        RaycastHit rayHit;
        //foreach(ChunkGenerator chunk in adjacentChunks){
        Debug.DrawRay(transform.position, transform.TransformDirection(Vector3.forward) * 1000, Color.white);
        if(Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out rayHit, maxDistance, layerMask)){
            ChunkGenerator chunk = rayHit.transform.GetComponent<ChunkGenerator>();
                //targetted chunk.
        }
        //}

    }
}
