using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;
using Unity.Mathematics;
using Unity.Collections.LowLevel.Unsafe;

using UnityEngine.UIElements;
using System.Data;
using Unity.Collections;

[RequireComponent(typeof(MeshRenderer))]

public class ChunkGenerator : MonoBehaviour
{
    // Start is called before the first frame update
    public int worldX;
    public int worldZ;

    MeshRenderer meshRenderer;
    MeshFilter meshFilter;

    MeshCollider meshCollider;


    int[,,] blockArray;

    public readonly int width = 20;
    readonly int height = 30;

    public float scale = 0.1f;
    public float zScale = 70;
    public bool isGenerated = false;
    public NativeHashMap<float3,int> blockType;

    public void GenerateMesh(float3[] verticesF, float2[] uvsF, int[] triangles, NativeHashMap<float3,int> blockType){
        meshRenderer = transform.GetComponent<MeshRenderer>();
        meshFilter = transform.GetComponent<MeshFilter>();
        meshCollider = transform.GetComponent<MeshCollider>();

        this.blockType = blockType;
        Vector3[] vertices = verticesF.Select(vertex => new Vector3(vertex.x,vertex.y, vertex.z)).ToArray();
        Vector2[] uvs = uvsF.Select(uv => new Vector2(uv.x,uv.y)).ToArray();

        Mesh mesh = new()
        {
            indexFormat = UnityEngine.Rendering.IndexFormat.UInt32,
            vertices = vertices,
            uv = uvs,
            triangles = triangles
        };


        mesh.Optimize();
        mesh.RecalculateBounds();
        mesh.RecalculateTangents();
        mesh.RecalculateNormals();
        meshFilter.mesh = mesh;
        meshCollider.sharedMesh = mesh;

        isGenerated = true;
    }

    public String getIndexKey(){
        return worldX + "," + worldZ;
    }

    public void Dispose(){
        blockType.Dispose();
    }
}
